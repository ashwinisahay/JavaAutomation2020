package com.chew.qa.pageFactoryandMethodes;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.chew.qa.basefile.BaseClassForReadFileAndBrowser;

public class ProductDetailPage extends BaseClassForReadFileAndBrowser {

	// Page Factory.

	@FindBy(className = "cw-btn cw-btn--action cw-btn--full js-add-cart")
	WebElement AddToCartButton;

	@FindBy(xpath = "//*[@id=\"product-title\"]/h1")
	WebElement ItemDescription;

	public ProductDetailPage() {

		PageFactory.initElements(driver, this);

	}

	public void ValidateSearchedItemprsentornot() {

		String Actual_Item = prop.getProperty("Search_Item");
		String Expected_Item = ItemDescription.getText();
		System.out.println(Expected_Item);
		// Assert.assertEquals(Expected_Item, Actual_Item);

		if (Expected_Item.equalsIgnoreCase(Actual_Item)) {

			System.out.println("Search result Matched -  We are in Product Detail page");

		} else {

			System.out.println("Search result Not Matched -  We are not in Product Details page");
			driver.quit();
		}

	}

	public MyCartValidation AddToCardValidationandClick() {

		String AddToCardText = AddToCartButton.getText();
		String Actual_AddtocartText = prop.getProperty("AddToCartText");

		if (AddToCardText.equalsIgnoreCase(Actual_AddtocartText)) {

			System.out.println("Search result Matched -  We are not in Product Details page");
			AddToCartButton.click();
		} else {

			System.out.println("Search result Not Matched -  We are not in Product Details page");
			driver.quit();

		}

		return new MyCartValidation();
	}

}
