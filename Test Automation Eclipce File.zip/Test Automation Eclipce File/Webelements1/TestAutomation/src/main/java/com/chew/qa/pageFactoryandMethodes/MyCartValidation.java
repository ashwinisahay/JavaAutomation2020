/**
 * 
 */
package com.chew.qa.pageFactoryandMethodes;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.chew.qa.basefile.BaseClassForReadFileAndBrowser;

/**
 * @author Ashwini Kumar
 *
 */
public class MyCartValidation extends BaseClassForReadFileAndBrowser {

	// Page Factory.

	@FindBy(className = "sfw-product-sku__added__label")
	WebElement addedtoyourcart;

	@FindBy(className = "cw-btn cw-btn--action")
	WebElement ProceedtoCheckout;

	@FindBy(className = "cw-btn cw-btn--default")
	WebElement AddToCart;

	public void validateItemOnCart() {

		String Actual_cartvalidation = addedtoyourcart.getText();
		String Expected_cartvalidation = prop.getProperty("Cartverificationtext");

		if (Actual_cartvalidation.equalsIgnoreCase(Expected_cartvalidation)) {

			System.out.println("Item has been added in the cart");
		} else {

			System.out.println("Item has been added in the cart");
		}

	}

	public void ProceedtoCheckoutispresent() {

		String Actual_CheckoutText = ProceedtoCheckout.getText();
		String Expected_CheckoutText = prop.getProperty("CheckoutText");

		if (Actual_CheckoutText.equalsIgnoreCase(Expected_CheckoutText)) {

			System.out.println("We are in Checkout Page.");
		} else {

			System.out.println("We are not in Checkout Page.");
		}

	}

	public YourShoppingCart ClickOnCartButton() {

		if (AddToCart.isDisplayed()) {

			AddToCart.click();
		} else {

			driver.quit();
		}

		return new YourShoppingCart();

	}

}
