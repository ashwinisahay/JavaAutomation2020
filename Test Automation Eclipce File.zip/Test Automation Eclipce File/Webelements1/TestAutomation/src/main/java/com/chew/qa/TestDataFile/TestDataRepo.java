package com.chew.qa.TestDataFile;

import com.chew.qa.basefile.BaseClassForReadFileAndBrowser;

public class TestDataRepo extends BaseClassForReadFileAndBrowser{
	
	
	public static String Search_Item = "Vetsulin";
	public static String Search_SKU = "146103";
	public static String specific_item = "Insulin U-40 for Dogs & Cats, 10-mL";
	public static String AddToCartText = "Add to cart";
	public static String Cartverificationtext = "added to your cart";
	public static String CheckoutText = "Proceed to Checkout";
	public static String YourShoppingcart = "Your Shopping Cart.";
	public static String YourShoppingcartIsEmpty = "Your cart is empty.";
	
	
	
}
