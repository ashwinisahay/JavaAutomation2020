/**
 * 
 */
package com.chew.qa.pageFactoryandMethodes;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.chew.qa.TestDataFile.*;

import com.chew.qa.basefile.BaseClassForReadFileAndBrowser;

/**
 * @author Ashwini Kumar
 *
 */
public class HomePageToSearchItem extends BaseClassForReadFileAndBrowser {

	// Page Factory.

	@FindBy(xpath = "//*[@id=\"search-autocomplete\"]")
	WebElement Searchfield;

	@FindBy(xpath = "//*[@id=\\\"header-searchform\\\"]/div/button/span/span/svg")
	WebElement ClickSubmit;

	public HomePageToSearchItem() {

		PageFactory.initElements(driver, this);

	}

	public ProductListPageItemSelection Searchitem() {

		driver.manage().timeouts().implicitlyWait(7, TimeUnit.SECONDS);
		//Searchfield.clear();
		String SD = TestDataRepo.Search_Item;
		System.out.println(SD);
		Searchfield.sendKeys("Vetsulin");
		//Searchfield.sendKeys(prop.getProperty(TestDataRepo.Search_Item));
		ClickSubmit.click();
		return new ProductListPageItemSelection();
	}

	public ProductListPageItemSelection SearchSKU() {
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		boolean SearchFieldEmable = Searchfield.isEnabled();
		Searchfield.clear();

		if (SearchFieldEmable == true) {

			String SS = prop.getProperty("Search_SKU");
			System.out.println(SS);
			Searchfield.sendKeys(SS);
			ClickSubmit.click();

		}

		return new ProductListPageItemSelection();
	}

}
