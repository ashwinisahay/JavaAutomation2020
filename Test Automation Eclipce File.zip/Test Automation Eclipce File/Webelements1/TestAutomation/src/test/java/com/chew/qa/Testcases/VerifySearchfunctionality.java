/**
 * 
 */
package com.chew.qa.Testcases;

import com.chew.qa.pageFactoryandMethodes.*;
import com.chew.qa.pageFactoryandMethodes.HomePageToSearchItem;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.chew.qa.basefile.BaseClassForReadFileAndBrowser;

/**
 * @author Ashwini Kumar
 *
 */
public class VerifySearchfunctionality extends BaseClassForReadFileAndBrowser {

	private static final String priority = null;
	VerifySearchfunctionality SearchpageObject;
	HomePageToSearchItem HomePageToSearchItem;
	ProductListPageItemSelection ProductListPageItemSelection;
	ProductDetailPage ProductDetailPage;
	MyCartValidation MyCartValidation;
	YourShoppingCart YourShoppingCart;

	public VerifySearchfunctionality() {
		super();
	}

	// Browser initialization.
	// 1.Open a browser to chewy.com
	@BeforeTest
	public void setUp() {

		initialzation();
		SearchpageObject = new VerifySearchfunctionality();
		HomePageToSearchItem = new HomePageToSearchItem();

	}

	// 2. Search a product by name
	@Test(priority = 1)
	public void SearchItembyVetsulin() {
		HomePageToSearchItem.Searchitem();

	}

	// 4. Verify results of search
	// 5. Click into specific item “Vetsulin Insulin U-40 for Dogs & Cats, 10-mL”
	@Test(priority = 2)
	public void ProductListPagevalidation() {

		ProductListPageItemSelection.ValidateSearchresultforItem();
		ProductListPageItemSelection.SelectItem();
	}

	// 6. Verify landed on product detail
	// 7. Add Item to your cart
	@Test(priority = 3)
	public void ProductDetailPageValidation() {

		ProductDetailPage.ValidateSearchedItemprsentornot();
		ProductDetailPage.AddToCardValidationandClick();
	}

	// 8. Verify item added to cart
	// 9. Navigate to cart
	// 10. Verify cart contents
	@Test(priority = 4)
	public void MyCartValidationValidation() {

		MyCartValidation.validateItemOnCart();
		MyCartValidation.ProceedtoCheckoutispresent();
		MyCartValidation.ClickOnCartButton();
	}
	// 10. Verify cart contents
	// 11. Empty cart
	// 12. Verify cart is empty

	@Test(priority = 5)
	public void YourShoppingCartValidation() {

		YourShoppingCart.validateYourShoppingCarttext();
		YourShoppingCart.validateItemAddedAtShoppingCart();
		YourShoppingCart.ClickEmptycart();
		YourShoppingCart.ValidateEmptyCart();
	}

	// 13. Close Browser
	@AfterMethod
	public void tearDown() {

		driver.quit();
	}

}
