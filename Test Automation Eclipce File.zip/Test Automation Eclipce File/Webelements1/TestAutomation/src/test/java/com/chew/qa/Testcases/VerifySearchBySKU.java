package com.chew.qa.Testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.chew.qa.basefile.BaseClassForReadFileAndBrowser;
import com.chew.qa.pageFactoryandMethodes.HomePageToSearchItem;
import com.chew.qa.pageFactoryandMethodes.MyCartValidation;
import com.chew.qa.pageFactoryandMethodes.ProductDetailPage;
import com.chew.qa.pageFactoryandMethodes.ProductListPageItemSelection;
import com.chew.qa.pageFactoryandMethodes.YourShoppingCart;

public class VerifySearchBySKU extends BaseClassForReadFileAndBrowser {

	private static final String priority = null;
	VerifySearchBySKU SearchSKUObject;
	HomePageToSearchItem HomePageToSearchItem;
	ProductListPageItemSelection ProductListPageItemSelection;
	ProductDetailPage ProductDetailPage;
	MyCartValidation MyCartValidation;
	YourShoppingCart YourShoppingCart;

	public VerifySearchBySKU() {
		super();
	}

	// Browser initialization.
	// 1.Open a browser to chewy.com
	@BeforeTest
	public void setUp() {

		initialzation();
		SearchSKUObject = new VerifySearchBySKU();
	}

	// 2. Search a product by SKU
	@Test(priority = 1)
	public void SearchItembySKU() {
		HomePageToSearchItem.SearchSKU();

	}

	// 4. Verify results of search
	@Test(priority = 2)
	public void ValidateSKUsearch() {

		ProductListPageItemSelection.SelectItem();
		ProductListPageItemSelection.ValidatebySKU();
	}

	// 5. Click into specific item “Vetsulin Insulin U-40 for Dogs & Cats, 10-mL”
	@Test(priority = 3)
	public void ValidateSKUAtProductdetailspage() {

		ProductDetailPage.ValidateSearchedItemprsentornot();
		ProductDetailPage.AddToCardValidationandClick();

	}

	// 8. Verify item added to cart
	// 9. Navigate to cart
	// 10. Verify cart contents
	@Test(priority = 4)
	public void MyCartValidationSKUValidation() {

		MyCartValidation.validateItemOnCart();
		MyCartValidation.ProceedtoCheckoutispresent();
		MyCartValidation.ClickOnCartButton();
	}
	// 10. Verify cart contents

	@Test(priority = 5)
	public void YourShoppingCartSKUValidation() {

		YourShoppingCart.validateYourShoppingCarttext();
		YourShoppingCart.validateItemAddedAtShoppingCart();
	}

	// 13. Close Browser
	//@AfterMethod
	//public void tearDown() {

		//driver.quit();
//}
//
}
